export interface Movie {
  id: string;
  title: string;
  description: string;
  image: string; // url de la imagen
}

