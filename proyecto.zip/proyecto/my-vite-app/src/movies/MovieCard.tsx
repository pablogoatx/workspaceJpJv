import { Link } from "react-router-dom";
import type { Movie } from "../models/movie.model";

interface MovieCardProps {
  movie: Movie;
}

export default function MovieCard({ movie }: MovieCardProps) {
  const { id, title, description, image } = movie;

  return (
    <Link
      to={`/movies/${id}`}
      className="block hover:scale-[1.01] transition"
    >
      <div className="flex bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition">

        {/* Imagen */}
        <div className="w-32 sm:w-40 h-48 flex-shrink-0">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Info */}
        <div className="p-4 flex flex-col justify-center">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">
            {title}
          </h2>
          <p className="text-gray-600 text-sm leading-relaxed">
            {description}
          </p>
        </div>

      </div>
    </Link>
  );
}

