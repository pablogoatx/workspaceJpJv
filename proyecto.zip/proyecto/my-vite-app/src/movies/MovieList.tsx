import type { Movie } from "../models/movie.model";
import MovieCard from "./MovieCard";

export default function MovieList() {
  const movies: Movie[] = [
    {
      id: "thebatman",
      title: "The Batman",
      description: "Parte 1",
      image: "https://image.tmdb.org/t/p/w500/74xTEgt7R36Fpooo50r9T25onhq.jpg",
    },
    {
      id: "mariobros",
      title: "Mario Bros",
      description: "The Mario Bros movie",
      image: "https://image.tmdb.org/t/p/w500/qNBAXBIQlnOThrVvA6mA2B5ggV6.jpg",
    },
  ];

  return (
    <div className="flex flex-col gap-4">
      {movies.map((movie) => (
        <MovieCard key={movie.id} movie={movie} />
      ))}
    </div>
  );
}

