import MovieList from "./MovieList";

export default function Movies() {
  return (
    <div className="flex flex-col items-center min-h-screen bg-gray-100 text-gray-800 px-6 py-8">
      
      {/* Título */}
      <h1 className="text-4xl font-bold mb-6">
        Movies Page
      </h1>

      {/* Lista de películas */}
      <div className="w-full max-w-5xl flex flex-col gap-4">
        <MovieList />
      </div>

    </div>
  );
}
