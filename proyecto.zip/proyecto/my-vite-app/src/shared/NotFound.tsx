export default function NotFound() {
  return (
    <div>
      <p>La pagina no fue encontrada</p>
    </div>
  );
}