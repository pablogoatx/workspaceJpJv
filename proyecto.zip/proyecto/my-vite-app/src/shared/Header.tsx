export default function Header() {
  return (
    <header className="w-full bg-gray-900 px-6 py-4">
      <div className="flex items-center gap-6">
        <a
          href="/"
          className="text-white font-semibold hover:text-blue-400 transition"
        >
          Home
        </a>
        <a
          href="/movies"
          className="text-white font-semibold hover:text-blue-400 transition"
        >
          Movies
        </a>
      </div>
    </header>
  );
}
